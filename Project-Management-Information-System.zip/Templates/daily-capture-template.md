---
date: "{{date}}"
time: "{{time}}"
project: "{{project}}"
contact: "{{contact}}"
tags:
  - daily
  - inbox
---
## Notes
{{notes}}

## Parts to Order
{{parts}}

---
*Process these notes into project files at end of day*
